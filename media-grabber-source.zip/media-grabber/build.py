#!/usr/bin/env python3
"""Construit les archives Chrome/Edge et Firefox à partir des mêmes sources.

    python3 build.py            -> dist/media-grabber-chrome.zip et dist/media-grabber-firefox.zip
    (dossiers dépliés : dist/chrome/ et dist/firefox/, utiles pour « charger l'extension non empaquetée »
     et pour about:debugging)
"""
import os, shutil, zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(ROOT, "dist")
SHARED = [
    "background.js", "popup.html", "popup.js", "download.html", "download.js",
    "hls.js", "mp4build.js", "queue.js", "lib/mux-mp4.min.js", "lib/mux.js.LICENSE.txt",
]
MANIFESTS = {"chrome": "manifest.json", "firefox": "manifest.firefox.json"}

def build(target):
    out = os.path.join(DIST, target)
    shutil.rmtree(out, ignore_errors=True)
    for f in SHARED:
        dst = os.path.join(out, f)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(os.path.join(ROOT, f), dst)
    shutil.copy2(os.path.join(ROOT, MANIFESTS[target]), os.path.join(out, "manifest.json"))
    archive = os.path.join(DIST, f"media-grabber-{target}.zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for base, _, files in os.walk(out):
            for name in sorted(files):
                full = os.path.join(base, name)
                z.write(full, os.path.relpath(full, out))
    print(f"{target:8} -> {archive}")

if __name__ == "__main__":
    for t in MANIFESTS:
        build(t)
