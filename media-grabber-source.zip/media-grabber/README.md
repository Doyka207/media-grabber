# Media Grabber 0.5.0

Détecte les fichiers vidéo/audio chargés par la page et les télécharge. Les flux HLS sont assemblés
dans le navigateur (AES-128 déchiffré localement) et enregistrés en MP4 classique. Aucune donnée n'est envoyée nulle part.

## Gestionnaire de téléchargements (page « Téléchargements »)
- **File d'attente** : toutes les vidéos s'ajoutent à la même page ; nombre de téléchargements simultanés réglable (1 à 4).
- **Limite de débit** partagée par toutes les vidéos (illimitée, 256 Ko/s … 10 Mo/s) et nombre de segments en parallèle par vidéo.
  Les réglages sont mémorisés.
- **Pause / reprise** : un téléchargement en pause ou interrompu repart au segment qui a échoué, sans rien réécrire.
  Le fichier obtenu est identique, octet pour octet, à celui d'un téléchargement sans incident.
- **Nouvelles tentatives automatiques** (réseau, erreurs 5xx, 429 avec `Retry-After`, serveur muet) avec attente croissante.
  Les refus 401/403 et les 404/410 échouent tout de suite : réessayer ne servirait à rien.
- **Jeton expiré** : l'erreur propose un champ pour coller la nouvelle URL de la playlist ; la reprise se fait au même segment
  (la page vérifie qu'il s'agit de la même vidéo : même nombre de segments, même durée).
- **Retour du réseau** : les téléchargements tombés en panne à cause de la connexion reprennent seuls.
- **Erreurs expliquées** : ce qui a échoué, où dans la vidéo (segment n/N, minute), pourquoi, et quoi faire
  (accès refusé, lien expiré, segment introuvable, serveur surchargé, connexion coupée, clé refusée, disque plein…).

Limite : la reprise fonctionne tant que la page « Téléchargements » reste ouverte. Si tu fermes l'onglet ou le navigateur,
le téléchargement en cours est perdu (l'état de la conversion n'est pas sauvegardé).

## Construire
    python3 build.py        # -> dist/media-grabber-chrome.zip et dist/media-grabber-firefox.zip
Les deux navigateurs partagent le même code ; seuls les manifestes diffèrent
(`manifest.json` = Chrome/Edge/Brave, `manifest.firefox.json` = Firefox).

## Chrome / Edge / Brave
1. Décompresser `media-grabber-chrome.zip`.
2. `chrome://extensions` → « Mode développeur » → « Charger l'extension non empaquetée » → choisir le dossier.

## Firefox (142 ou plus récent)
- Test : `about:debugging#/runtime/this-firefox` → « Charger un module complémentaire temporaire… » →
  choisir `manifest.json` du dossier décompressé (ou le zip). Retiré au redémarrage de Firefox.
- Installation durable : Firefox n'accepte que les extensions signées. Change d'abord l'identifiant
  (`browser_specific_settings.gecko.id` dans `manifest.firefox.json`) puis fais-la signer sur addons.mozilla.org
  (distribution « non listée », gratuite). Firefox Developer Edition / Nightly / ESR acceptent aussi les extensions
  non signées avec `xpinstall.signatures.required = false`.
- Permissions : en MV3, Firefox traite l'accès aux sites comme optionnel. Si le popup affiche
  « Autoriser l'accès aux sites », clique dessus (ou active-le dans `about:addons` → l'extension → Permissions),
  puis recharge la page de la vidéo.
- Enregistrement : Firefox n'a pas de sélecteur de fichier pour les pages web. Le MP4 est écrit dans l'espace
  privé de l'extension (OPFS, sur disque), puis copié dans le dossier Téléchargements : il faut donc
  temporairement la place du fichier en double.

## Limites
Flux en direct, DRM et chiffrement SAMPLE-AES non pris en charge ; piste audio séparée (HLS) non fusionnée ;
conversion MP4 limitée à H.264 + AAC (sinon choisir « TS brut »).
