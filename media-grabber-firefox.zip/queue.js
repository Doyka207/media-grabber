// queue.js - file d'attente de téléchargements : nombre maximal de téléchargements simultanés,
// pause / reprise / annulation, reprise automatique après une coupure réseau.
// Ne dépend ni du DOM ni de hls.js : une « entrée » est n'importe quel objet qui expose
//   run() -> Promise      (rejette avec une erreur portant .code : "paused" | "aborted" | autre)
//   pause()  /  cancel()
(function (root) {
  "use strict";

  // statuts : queued | running | paused | done | failed | cancelled
  class JobQueue {
    constructor({ maxParallel = 2, onChange = () => {} } = {}) {
      this.maxParallel = Math.max(1, maxParallel);
      this.onChange = onChange;
      this.entries = [];
      this._prio = 0;
      this._seq = 0;
    }

    get running() {
      return this.entries.filter((e) => e.status === "running").length;
    }

    // Reste-t-il quelque chose que l'utilisateur perdrait en fermant la page ?
    hasActive() {
      return this.entries.some(
        (e) =>
          ["queued", "running", "paused"].includes(e.status) ||
          (e.status === "failed" && e.error && e.error.resumable !== false)
      );
    }

    _changed() {
      try {
        this.onChange(this);
      } catch (e) {
        console.error(e);
      }
    }

    add(entry) {
      entry.id = entry.id || `job-${++this._seq}`;
      entry.status = "queued";
      entry.error = null;
      entry.prio = 0;
      this.entries.push(entry);
      this._changed();
      this.schedule();
      return entry;
    }

    get(id) {
      return this.entries.find((e) => e.id === id);
    }

    setMaxParallel(n) {
      this.maxParallel = Math.max(1, n | 0);
      this.schedule();
      this._changed();
    }

    // Lance les entrées en attente tant qu'il reste de la place ; une entrée reprise passe avant les autres.
    schedule() {
      while (this.running < this.maxParallel) {
        let best = null;
        for (const e of this.entries) {
          if (e.status === "queued" && (!best || e.prio > best.prio)) best = e;
        }
        if (!best) break;
        this._start(best);
      }
    }

    _start(e) {
      e.status = "running";
      e.error = null;
      this._changed();
      Promise.resolve()
        .then(() => e.run())
        .then(
          (res) => {
            e.status = "done";
            e.result = res;
          },
          (err) => {
            e.error = err;
            const code = err && err.code;
            if (code === "paused") e.status = "paused";
            else if (code === "aborted") e.status = "cancelled";
            else e.status = "failed";
          }
        )
        .then(() => {
          this._changed();
          this.schedule();
        });
    }

    pause(id) {
      const e = this.get(id);
      if (!e) return;
      if (e.status === "running") e.pause();
      else if (e.status === "queued") {
        e.status = "paused";
        this._changed();
      }
    }

    resume(id) {
      const e = this.get(id);
      if (!e || !["paused", "failed"].includes(e.status)) return;
      if (e.status === "failed" && e.error && e.error.resumable === false) return;
      e.status = "queued";
      e.prio = ++this._prio;
      this._changed();
      this.schedule();
    }

    cancel(id) {
      const e = this.get(id);
      if (!e) return;
      if (e.status === "running") e.cancel();
      else if (["queued", "paused", "failed"].includes(e.status)) {
        if (e.cancel) e.cancel();
        e.status = "cancelled";
        this._changed();
        this.schedule();
      }
    }

    // Retire une entrée terminée, annulée ou définitivement en échec.
    remove(id) {
      const e = this.get(id);
      if (!e) return false;
      const final = ["done", "cancelled"].includes(e.status) || (e.status === "failed" && e.error && e.error.resumable === false);
      if (!final) return false;
      this.entries = this.entries.filter((x) => x !== e);
      this._changed();
      return true;
    }

    // Retour du réseau : relance les téléchargements tombés en panne à cause de la connexion.
    resumeNetworkFailures() {
      let n = 0;
      for (const e of this.entries) {
        if (e.status === "failed" && e.error && e.error.resumable !== false && ["network", "timeout"].includes(e.error.code)) {
          this.resume(e.id);
          n++;
        }
      }
      return n;
    }
  }

  const API = { JobQueue };
  if (typeof module !== "undefined" && module.exports) module.exports = API;
  else root.JobQueue = JobQueue;
})(typeof globalThis !== "undefined" ? globalThis : self);
