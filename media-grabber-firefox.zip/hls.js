// hls.js - téléchargement HLS dans le navigateur (sans dépendance, hors mux.js pour TS -> MP4).
// Utilisable dans une page d'extension (global `HLS`) et sous Node (module.exports) pour les tests.
(function (root) {
  "use strict";

  const Mp4Builder =
    typeof module !== "undefined" && module.exports ? require("./mp4build.js").Mp4Builder : root.Mp4Builder;

  // ---------- Erreurs typées ----------
  // code : http-auth | http-gone | http-ratelimit | http-server | http | network | timeout | key |
  //        decrypt | write | process | playlist | aborted | paused
  // fatal : le job ne peut plus être repris (écriture impossible, état interne incohérent…)
  class HlsError extends Error {
    constructor(code, message, extra = {}) {
      super(message);
      this.name = "HlsError";
      this.code = code;
      Object.assign(this, extra);
    }
  }
  const abortError = () => new DOMException("Annulé", "AbortError");
  const isAbort = (e) => !!e && (e.name === "AbortError" || e.code === "aborted");

  const sleep = (ms, signal) =>
    new Promise((resolve, reject) => {
      if (signal && signal.aborted) return reject(abortError());
      const onAbort = () => {
        clearTimeout(t);
        reject(abortError());
      };
      const t = setTimeout(() => {
        if (signal) signal.removeEventListener("abort", onAbort);
        resolve();
      }, ms);
      if (signal) signal.addEventListener("abort", onAbort, { once: true });
    });

  // Limiteur de débit partagé entre tous les téléchargements (octets/s ; 0 = illimité).
  // Chaque lecture de données réserve un créneau : le débit moyen ne dépasse pas la limite.
  class RateLimiter {
    constructor(bytesPerSec = 0) {
      this.rate = bytesPerSec > 0 ? bytesPerSec : 0;
      this.next = 0;
    }
    setRate(bytesPerSec) {
      this.rate = bytesPerSec > 0 ? bytesPerSec : 0;
      this.next = 0;
    }
    // Réserve un créneau de n / débit secondes et attend sa FIN : la durée totale est donc toujours
    // au moins (octets ÷ débit), y compris pour le dernier morceau reçu.
    async take(n, signal) {
      if (!this.rate) return;
      const now = Date.now();
      const end = Math.max(now, this.next) + (n / this.rate) * 1000;
      this.next = end;
      if (end > now) await sleep(end - now, signal);
    }
  }

  const abs = (u, base) => new URL(u, base).href;

  // ---------- Parsing ----------

  function parseAttrs(line) {
    const out = {};
    const s = line.slice(line.indexOf(":") + 1);
    for (const m of s.matchAll(/([A-Z0-9-]+)=("[^"]*"|[^,]*)/g)) {
      out[m[1]] = m[2].replace(/^"|"$/g, "");
    }
    return out;
  }

  function isMaster(text) {
    return text.includes("#EXT-X-STREAM-INF");
  }

  function parseMaster(text, base) {
    const lines = text.split(/\r?\n/).map((l) => l.trim());
    const variants = [];
    const media = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (l.startsWith("#EXT-X-STREAM-INF:")) {
        const a = parseAttrs(l);
        let j = i + 1;
        while (j < lines.length && (!lines[j] || lines[j].startsWith("#"))) j++;
        if (j >= lines.length) break;
        variants.push({
          url: abs(lines[j], base),
          bandwidth: parseInt(a.BANDWIDTH, 10) || 0,
          resolution: a.RESOLUTION || "",
          codecs: a.CODECS || "",
          audioGroup: a.AUDIO || "",
        });
        i = j;
      } else if (l.startsWith("#EXT-X-MEDIA:")) {
        media.push(parseAttrs(l));
      }
    }
    variants.sort((a, b) => b.bandwidth - a.bandwidth);
    for (const v of variants) {
      v.separateAudio =
        !!v.audioGroup &&
        media.some((m) => m.TYPE === "AUDIO" && m["GROUP-ID"] === v.audioGroup && m.URI);
    }
    return { variants, media };
  }

  function parseMedia(text, base) {
    const lines = text.split(/\r?\n/);
    let seq = 0;
    let key = null;
    let map = null;
    let dur = 0;
    let br = null;
    let endlist = false;
    const lastEnd = {};
    const segments = [];

    // "longueur@offset" ; sans offset, on enchaîne après le dernier octet lu de la même URL
    const toRange = (spec, url) => {
      const [len, off] = spec.split("@").map(Number);
      const start = Number.isFinite(off) ? off : lastEnd[url] || 0;
      lastEnd[url] = start + len;
      return { start, end: start + len - 1 };
    };

    for (const raw of lines) {
      const line = raw.trim();
      if (!line) continue;
      if (line.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
        seq = parseInt(line.split(":")[1], 10) || 0;
      } else if (line.startsWith("#EXT-X-KEY:")) {
        const a = parseAttrs(line);
        if (a.METHOD === "NONE") key = null;
        else {
          const identity = !a.KEYFORMAT || a.KEYFORMAT === "identity";
          key = {
            method: a.METHOD,
            supported: a.METHOD === "AES-128" && identity && !!a.URI,
            uri: a.URI ? abs(a.URI, base) : null,
            iv: a.IV || null,
          };
        }
      } else if (line.startsWith("#EXT-X-MAP:")) {
        const a = parseAttrs(line);
        const url = abs(a.URI, base);
        map = { url, range: a.BYTERANGE ? toRange(a.BYTERANGE, url) : null };
      } else if (line.startsWith("#EXTINF:")) {
        dur = parseFloat(line.slice(8)) || 0;
      } else if (line.startsWith("#EXT-X-BYTERANGE:")) {
        br = line.slice(17);
      } else if (line === "#EXT-X-ENDLIST") {
        endlist = true;
      } else if (!line.startsWith("#")) {
        const url = abs(line, base);
        segments.push({
          url,
          duration: dur,
          seq: seq + segments.length,
          key,
          map,
          range: br ? toRange(br, url) : null,
        });
        dur = 0;
        br = null;
      }
    }
    return {
      segments,
      endlist,
      totalDuration: segments.reduce((s, x) => s + x.duration, 0),
    };
  }

  // ---------- Détection du type de conteneur ----------

  function sniff(b) {
    if (b.length > 188 && b[0] === 0x47 && b[188] === 0x47) return "ts";
    if (b.length > 3 && b.length <= 188 && b[0] === 0x47) return "ts";
    if (b.length > 8) {
      const t = String.fromCharCode(b[4], b[5], b[6], b[7]);
      if (/^(ftyp|styp|moof|moov)$/.test(t)) return "fmp4";
    }
    let o = 0;
    if (b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) {
      o = 10 + (((b[6] & 0x7f) << 21) | ((b[7] & 0x7f) << 14) | ((b[8] & 0x7f) << 7) | (b[9] & 0x7f));
    }
    if (b[o] === 0xff) {
      if ((b[o + 1] & 0xf6) === 0xf0) return "aac";
      if ((b[o + 1] & 0xe0) === 0xe0) return "mp3";
    }
    return "unknown";
  }

  // format : "mp4"  = MP4 classique (index complet, recommandé)
  //          "fmp4" = MP4 fragmenté (ancien comportement)
  //          "raw"  = concaténation brute des segments
  function extFor(kind, format) {
    if (kind === "ts") return format === "raw" ? "ts" : "mp4";
    if (kind === "fmp4") return "mp4";
    if (kind === "aac") return "aac";
    if (kind === "mp3") return "mp3";
    return "bin";
  }

  // ---------- Réseau ----------

  function retryAfterMs(h) {
    if (!h) return 0;
    const sec = Number(h);
    if (Number.isFinite(sec)) return Math.min(sec * 1000, 60000);
    const d = Date.parse(h);
    return Number.isFinite(d) ? Math.min(Math.max(d - Date.now(), 0), 60000) : 0;
  }

  function httpError(r, url) {
    const s = r.status;
    const ra = r.headers && r.headers.get ? retryAfterMs(r.headers.get("retry-after")) : 0;
    const info = { status: s, url };
    if (s === 401 || s === 403) return new HlsError("http-auth", `HTTP ${s}`, { ...info, retryable: false });
    if (s === 404 || s === 410) return new HlsError("http-gone", `HTTP ${s}`, { ...info, retryable: false });
    if (s === 429) return new HlsError("http-ratelimit", "HTTP 429", { ...info, retryable: true, retryAfter: ra });
    if (s === 408) return new HlsError("timeout", "HTTP 408", { ...info, retryable: true });
    if (s >= 500) return new HlsError("http-server", `HTTP ${s}`, { ...info, retryable: true, retryAfter: ra });
    return new HlsError("http", `HTTP ${s}`, { ...info, retryable: false });
  }

  function toHlsError(e, url) {
    if (e instanceof HlsError || isAbort(e)) return e;
    return new HlsError("network", (e && e.message) || String(e), { url, retryable: true, cause: e });
  }

  // Rejette dès que `signal` est annulé, même si l'opération sous-jacente ne réagit pas à l'annulation.
  function abortable(promise, signal) {
    if (!signal) return promise;
    return new Promise((resolve, reject) => {
      if (signal.aborted) return reject(abortError());
      const onAbort = () => reject(abortError());
      signal.addEventListener("abort", onAbort, { once: true });
      promise.then(
        (v) => {
          signal.removeEventListener("abort", onAbort);
          resolve(v);
        },
        (e) => {
          signal.removeEventListener("abort", onAbort);
          reject(e);
        }
      );
    });
  }

  // Lit le corps par morceaux : permet le délai d'inactivité, la limite de débit et le suivi des octets.
  // `reqSignal` : annulation de CETTE requête (délai dépassé, pause, annulation).
  async function readBody(r, { limiter, onBytes, signal, reqSignal, idle }) {
    if (!r.body || typeof r.body.getReader !== "function") {
      const b = new Uint8Array(await r.arrayBuffer());
      if (onBytes) onBytes(b.length);
      if (limiter) await limiter.take(b.length, signal);
      return b;
    }
    const reader = r.body.getReader();
    const chunks = [];
    let total = 0;
    try {
      for (;;) {
        const { done, value } = await abortable(reader.read(), reqSignal);
        if (done) break;
        chunks.push(value);
        total += value.length;
        if (onBytes) onBytes(value.length);
        if (limiter) {
          idle.disarm(); // l'attente imposée par la limite n'est pas une inactivité du serveur
          await limiter.take(value.length, signal);
        }
        idle.arm();
      }
    } catch (e) {
      reader.cancel().catch(() => {}); // libère la connexion
      throw e;
    }
    if (chunks.length === 1) return chunks[0];
    const out = new Uint8Array(total);
    let k = 0;
    for (const c of chunks) {
      out.set(c, k);
      k += c.length;
    }
    return out;
  }

  async function fetchOnce(url, { headers, range, signal, doFetch, limiter, onBytes, timeoutMs }) {
    if (signal && signal.aborted) throw abortError();
    const rc = new AbortController();
    const link = () => rc.abort();
    if (signal) signal.addEventListener("abort", link, { once: true });
    let timedOut = false;
    let timer = null;
    const idle = {
      arm: () => {
        clearTimeout(timer);
        timer = setTimeout(() => {
          timedOut = true;
          rc.abort();
        }, timeoutMs);
      },
      disarm: () => clearTimeout(timer),
    };
    try {
      idle.arm();
      const r = await abortable(doFetch(url, { headers, signal: rc.signal, credentials: "include" }), rc.signal);
      if (!r.ok) throw httpError(r, url);
      let bytes = await readBody(r, { limiter, onBytes, signal, reqSignal: rc.signal, idle });
      // Serveur qui ignore Range et renvoie tout le fichier
      if (range && r.status === 200) bytes = bytes.subarray(range.start, range.end + 1);
      return bytes;
    } catch (e) {
      if (timedOut) {
        throw new HlsError("timeout", `aucune donnée depuis ${timeoutMs >= 10000 ? Math.round(timeoutMs / 1000) : (timeoutMs / 1000).toFixed(1)} s`, { url, retryable: true });
      }
      if (signal && signal.aborted) throw abortError();
      throw e;
    } finally {
      clearTimeout(timer);
      if (signal) signal.removeEventListener("abort", link);
    }
  }

  // Nouvelles tentatives automatiques (réseau, 5xx, 429, délai dépassé) avec attente exponentielle ;
  // les refus 401/403 et les 404/410 échouent tout de suite : réessayer ne servirait à rien.
  async function fetchBytes(url, opts = {}) {
    const { range, signal, retries = 3, fetchImpl, limiter, onBytes, onRetry, timeoutMs = 30000, retryBaseMs = 500 } = opts;
    const doFetch = fetchImpl || fetch;
    const headers = range ? { Range: `bytes=${range.start}-${range.end}` } : {};
    for (let attempt = 0; ; attempt++) {
      try {
        return await fetchOnce(url, { headers, range, signal, doFetch, limiter, onBytes, timeoutMs });
      } catch (e0) {
        const e = toHlsError(e0, url);
        if (isAbort(e) || (signal && signal.aborted)) throw isAbort(e) ? e : abortError();
        e.attempts = attempt + 1;
        if (!e.retryable || attempt >= retries) throw e;
        const delay = Math.max(e.retryAfter || 0, retryBaseMs * 2 ** attempt);
        if (opts.onRetry) opts.onRetry({ attempt: attempt + 1, max: retries, delay, error: e, url });
        await sleep(delay, signal);
      }
    }
  }

  async function fetchText(url, opts) {
    return new TextDecoder().decode(await fetchBytes(url, opts));
  }

  // ---------- AES-128 (HLS "classique", pas du DRM) ----------

  function ivBytes(key, seq) {
    const iv = new Uint8Array(16);
    if (key.iv) {
      const hex = key.iv.replace(/^0x/i, "").padStart(32, "0");
      for (let i = 0; i < 16; i++) iv[i] = parseInt(hex.substr(i * 2, 2), 16);
    } else {
      const dv = new DataView(iv.buffer);
      dv.setUint32(8, Math.floor(seq / 2 ** 32));
      dv.setUint32(12, seq >>> 0);
    }
    return iv;
  }

  // `keys` : cache de clés partagé entre les exécutions d'un même job (une clé en échec est retirée du cache)
  function makeSegmentFetcher(netOpts, keys = new Map()) {
    const getKey = (uri) => {
      if (!keys.has(uri)) {
        const p = (async () => {
          let raw;
          try {
            raw = await fetchBytes(uri, netOpts);
          } catch (e) {
            if (e instanceof HlsError) e.resource = "key";
            throw e;
          }
          if (raw.length !== 16) {
            throw new HlsError("key", `Clé AES invalide (${raw.length} octets)`, { resource: "key", url: uri });
          }
          return crypto.subtle.importKey("raw", raw, "AES-CBC", false, ["decrypt"]);
        })();
        p.catch(() => keys.delete(uri));
        keys.set(uri, p);
      }
      return keys.get(uri);
    };
    return async function fetchSegment(seg) {
      let bytes = await fetchBytes(seg.url, { ...netOpts, range: seg.range });
      if (seg.key) {
        const k = await getKey(seg.key.uri);
        try {
          bytes = new Uint8Array(
            await crypto.subtle.decrypt({ name: "AES-CBC", iv: ivBytes(seg.key, seg.seq) }, k, bytes)
          );
        } catch (e) {
          throw new HlsError("decrypt", (e && e.message) || "déchiffrement impossible", { url: seg.url, cause: e });
        }
      }
      return bytes;
    };
  }

  // ---------- Préparation (analyse d'une media playlist) ----------

  // probe:false -> analyse la playlist seulement (pas de téléchargement du 1er segment, `kind` inconnu)
  async function prepare(mediaUrl, { signal, text, fetchImpl, probe = true, limiter, retries, timeoutMs, retryBaseMs, onRetry } = {}) {
    const netOpts = { signal, fetchImpl, limiter, retries, timeoutMs, retryBaseMs, onRetry };
    let txt = text;
    if (txt == null) {
      try {
        txt = await fetchText(mediaUrl, netOpts);
      } catch (e) {
        if (e instanceof HlsError) e.resource = "playlist";
        throw e;
      }
    }
    if (!txt.trimStart().startsWith("#EXTM3U")) {
      throw new HlsError("playlist", "Ce n'est pas une playlist HLS valide (la réponse du serveur n'est pas du HLS : jeton expiré ?).", { url: mediaUrl });
    }
    const pl = parseMedia(txt, mediaUrl);
    if (!pl.segments.length) throw new HlsError("playlist", "La playlist ne contient aucun segment.", { url: mediaUrl });
    if (!pl.endlist) {
      throw new HlsError("playlist", "Flux en direct (pas de EXT-X-ENDLIST) : non pris en charge dans cette version.", { url: mediaUrl });
    }
    const bad = pl.segments.find((s) => s.key && !s.key.supported);
    if (bad) {
      throw new HlsError(
        "playlist",
        `Flux protégé (${bad.key.method}) : seul le chiffrement AES-128 standard est pris en charge. ` +
          "Les flux sous DRM ne peuvent pas être téléchargés.",
        { url: mediaUrl }
      );
    }
    pl.encrypted = pl.segments.some((s) => s.key);
    pl.url = mediaUrl;
    if (!probe) {
      pl.kind = null;
      return pl;
    }
    return probeFirstSegment(pl, netOpts);
  }

  // Télécharge (et déchiffre) le 1er segment : sert à détecter le conteneur ; il est mis en cache pour le job.
  async function probeFirstSegment(pl, netOpts = {}) {
    const fetchSegment = makeSegmentFetcher(netOpts);
    try {
      pl.first = await fetchSegment(pl.segments[0]);
    } catch (e) {
      if (e instanceof HlsError) {
        Object.assign(e, { segmentIndex: 0, total: pl.segments.length, position: 0 });
        e.userMessage = describe(e);
      }
      throw e;
    }
    pl.kind = pl.segments[0].map ? "fmp4" : sniff(pl.first);
    return pl;
  }

  // ---------- Correctif de durée ----------
  // mux.js écrit 0xFFFFFFFF ("inconnue") comme durée dans mvhd/tkhd/mdhd : certains lecteurs
  // affichent alors ~13 h et une barre de lecture inutilisable. On écrit la vraie durée
  // (somme des EXTINF de la playlist). Ne touche que les boîtes en version 0 (32 bits).
  function patchInitDuration(init, seconds) {
    if (!(seconds > 0)) return init;
    const dv = new DataView(init.buffer, init.byteOffset, init.byteLength);
    let movieTs = 0;
    const set = (off, ts) => {
      const v = Math.round(seconds * ts);
      if (ts > 0 && v <= 0xffffffff) dv.setUint32(off, v);
    };
    const walk = (start, end) => {
      for (let p = start; p + 8 <= end; ) {
        const size = dv.getUint32(p);
        if (size < 8) break;
        const type = String.fromCharCode(init[p + 4], init[p + 5], init[p + 6], init[p + 7]);
        if (type === "moov" || type === "trak" || type === "mdia") {
          walk(p + 8, Math.min(p + size, end));
        } else if (init[p + 8] === 0) {
          if (type === "mvhd") { movieTs = dv.getUint32(p + 20); set(p + 24, movieTs); }
          else if (type === "tkhd") set(p + 28, movieTs);
          else if (type === "mdhd") set(p + 24, dv.getUint32(p + 20));
        }
        p += size;
      }
    };
    walk(0, init.byteLength);
    return init;
  }

  // ---------- Messages d'erreur ----------

  const fmtPos = (sec) => {
    const t = Math.round(sec);
    const h = Math.floor(t / 3600);
    const m = Math.floor((t % 3600) / 60);
    const r = t % 60;
    return (h ? `${h}:${String(m).padStart(2, "0")}` : `${m}`) + `:${String(r).padStart(2, "0")}`;
  };
  const hostOf = (u) => {
    try {
      return new URL(u).hostname;
    } catch {
      return "";
    }
  };
  const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);

  // Explique l'erreur à l'utilisateur : quoi, où dans la vidéo, pourquoi, que faire.
  function describe(err) {
    let what = "une ressource";
    if (err.resource === "key") what = "la clé de chiffrement";
    else if (err.resource === "init") what = "le segment d'initialisation";
    else if (err.resource === "playlist") what = "la playlist";
    else if (err.segmentIndex != null) {
      what = `le segment ${err.segmentIndex + 1}/${err.total} (à ${fmtPos(err.position || 0)})`;
    }
    const ofWhat = what.replace(/^le /, "du ").replace(/^la /, "de la ").replace(/^une /, "d'une ");
    const host = hostOf(err.url);
    const onHost = host ? ` sur ${host}` : "";
    const resume = err.segmentIndex != null ? ` pour reprendre au segment ${err.segmentIndex + 1}` : "";
    const tries = err.attempts > 1 ? ` après ${err.attempts} tentatives` : "";
    switch (err.code) {
      case "http-auth":
        return (
          `Accès refusé (HTTP ${err.status}) pour ${what}${onHost}. Le jeton de la playlist a probablement expiré, ` +
          `ou le serveur exige un Referer ou des cookies que le navigateur n'a pas envoyés. ` +
          `Recharge la page de la vidéo, copie la nouvelle URL de la playlist et colle-la ci-dessous${resume}.`
        );
      case "http-gone":
        return err.status === 410
          ? `${cap(what)} n'existe plus (HTTP 410)${onHost} : le lien a expiré. ` +
              `Recharge la page de la vidéo et colle la nouvelle URL de la playlist${resume}.`
          : `${cap(what)} est introuvable (HTTP 404)${onHost} : le serveur ne l'a plus ou la playlist est périmée. ` +
              `Recharge la page de la vidéo et colle la nouvelle URL de la playlist${resume}.`;
      case "http-ratelimit":
        return (
          `Le serveur limite le nombre de requêtes (HTTP 429)${onHost}${tries}. ` +
          `Réduis le nombre de segments en parallèle ou ajoute une limite de débit, puis reprends.`
        );
      case "http-server":
        return `Erreur du serveur (HTTP ${err.status})${onHost} pour ${what}${tries}. Le serveur est peut-être surchargé : reprends dans quelques minutes.`;
      case "network":
        return (
          `Connexion interrompue ou bloquée pendant le téléchargement ${ofWhat}${onHost}${tries}. ` +
          `Vérifie ta connexion Internet ; le téléchargement reprendra tout seul au retour du réseau. ` +
          `Si cela arrive dès le début, vérifie que l'extension a l'autorisation d'accéder aux sites.`
        );
      case "timeout":
        return `Le serveur ne répond plus pour ${what}${onHost}${tries} (${err.message}). Reprends le téléchargement ; si cela se répète, réduis le nombre de segments en parallèle.`;
      case "key":
        return err.status
          ? `Clé de chiffrement refusée (HTTP ${err.status})${onHost}. ` +
              `Sans elle les segments ne peuvent pas être déchiffrés : recharge la page de la vidéo et colle la nouvelle URL de la playlist.`
          : `${err.message}${onHost}. Le serveur n'a pas renvoyé une vraie clé (lien expiré ?) : recharge la page de la vidéo et colle la nouvelle URL de la playlist.`;
      case "decrypt":
        return `Déchiffrement impossible pour ${what} : le segment est tronqué ou la clé ne correspond pas. Reprends pour le retélécharger.`;
      case "write": {
        const why = err.cause && err.cause.name ? ` (${err.cause.name})` : "";
        return `Écriture impossible sur le disque${why}. Espace insuffisant ou fichier verrouillé ? Libère de la place puis relance un nouveau téléchargement.`;
      }
      case "playlist":
        return err.message;
      case "paused":
        return "En pause.";
      case "aborted":
        return "Annulé.";
      default:
        return `${err.message || "Erreur inconnue"}${err.segmentIndex != null ? ` (${what})` : ""}.`;
    }
  }

  // ---------- Téléchargement (reprenable) ----------

  // Un job conserve son état entre deux appels à run() : segment suivant, tables MP4, transmuxeur mux.js,
  // clés AES. Après un échec réseau, une pause ou un jeton expiré, run() repart au segment qui a échoué,
  // sans rien réécrire de ce qui est déjà dans le fichier.
  class DownloadJob {
    // opts : format, write, patchHead, concurrency, limiter, fetchImpl, muxjs, mp4Options, signal,
    //        retries, timeoutMs, retryBaseMs
    constructor(pl, opts = {}) {
      this.pl = pl;
      this.opts = opts;
      this.format = opts.format || "mp4";
      this.n = pl.segments.length;
      this.state = "idle"; // idle | running | paused | failed | done | cancelled
      this.error = null;
      this.result = null;
      this.next = 0; // index du prochain segment à TRAITER (tout ce qui précède est écrit)
      this.bytesIn = 0;
      this.bytesOut = 0;
      this.netBytes = 0;
      this.keys = new Map();
      this._listeners = [];
      this._samples = [];
      this._pausing = false;
      this._cancelled = false;

      // MP4 classique : reconstruit un moov complet (TS converti par mux.js, ou fMP4 source)
      this.classic = this.format === "mp4" && (pl.kind === "ts" || pl.kind === "fmp4");
      this.convert = pl.kind === "ts" && (this.format === "mp4" || this.format === "fmp4");
      if (this.classic && typeof opts.patchHead !== "function") {
        throw new Error("Le MP4 classique exige une fonction patchHead (réécriture de l'en-tête).");
      }
      this.builder = this.classic ? new Mp4Builder(opts.mp4Options) : null;
      this.pending = [];
      this.initDone = false; // transmuxeur : init segment reçu
      this.initWritten = false; // fMP4 : init segment (EXT-X-MAP) traité
      this.started = false; // MP4 classique : zone d'en-tête réservée
      this.tx = null;
      if (this.convert) {
        const M = opts.muxjs || root.muxjs;
        if (!M) throw new Error("mux.js n'est pas chargé.");
        const T = (M.mp4 && M.mp4.Transmuxer) || M.Transmuxer;
        this.tx = new T({ keepOriginalTimestamps: false });
        this.tx.on("data", (d) => {
          if (!d.data || !d.data.byteLength) return;
          if (!this.initDone) {
            this.initDone = true;
            if (this.classic) this.builder.setInit(d.initSegment);
            else this.pending.push(patchInitDuration(d.initSegment, pl.totalDuration));
          }
          this.pending.push(d.data);
        });
      }
      this._computeStarts();
      if (opts.signal) {
        if (opts.signal.aborted) this._cancelled = true;
        else opts.signal.addEventListener("abort", () => this.cancel(), { once: true });
      }
    }

    _computeStarts() {
      this.starts = [];
      let t = 0;
      for (const sg of this.pl.segments) {
        this.starts.push(t);
        t += sg.duration;
      }
    }

    on(fn) {
      this._listeners.push(fn);
      return () => (this._listeners = this._listeners.filter((f) => f !== fn));
    }
    _emit(type, extra = {}) {
      for (const fn of this._listeners.slice()) {
        try {
          fn({ type, job: this, ...extra });
        } catch (e) {
          console.error(e);
        }
      }
    }

    stats() {
      const now = Date.now();
      while (this._samples.length > 2 && now - this._samples[0][0] > 4000) this._samples.shift();
      let speed = 0;
      if (this.state === "running" && this._samples.length >= 2) {
        const a = this._samples[0];
        const b = this._samples[this._samples.length - 1];
        speed = (b[1] - a[1]) / Math.max((b[0] - a[0]) / 1000, 0.001);
      }
      const avgSeg = this.next ? this.bytesIn / this.next : 0;
      const eta = speed > 0 && avgSeg ? ((this.n - this.next) * avgSeg) / speed : 0;
      return { done: this.next, total: this.n, bytes: this.bytesIn, net: this.netBytes, speed, eta, state: this.state };
    }

    pause() {
      if (this.state !== "running") return;
      this._pausing = true;
      this._ac.abort();
    }

    cancel() {
      this._cancelled = true;
      if (this.state === "running") this._ac.abort();
      else if (this.state !== "done") {
        this.state = "cancelled";
        this._emit("state");
      }
    }

    // Jeton expiré : remplace les URL des segments par celles d'une playlist « fraîche » de la même vidéo.
    replacePlaylist(newPl) {
      if (this.state === "running") throw new HlsError("playlist", "Mets d'abord le téléchargement en pause.", { fatal: false });
      if (newPl.segments.length !== this.n) {
        throw new HlsError(
          "playlist",
          `La nouvelle playlist contient ${newPl.segments.length} segments au lieu de ${this.n} : ce n'est pas la même vidéo (ou la même qualité).`
        );
      }
      const oldTotal = this.pl.segments.reduce((a, x) => a + x.duration, 0);
      const newTotal = newPl.segments.reduce((a, x) => a + x.duration, 0);
      if (Math.abs(oldTotal - newTotal) > Math.max(1, oldTotal * 0.02)) {
        throw new HlsError(
          "playlist",
          `La durée de la nouvelle playlist (${fmtPos(newTotal)}) ne correspond pas à celle de la vidéo en cours (${fmtPos(oldTotal)}).`
        );
      }
      this.pl.segments = newPl.segments;
      this.pl.url = newPl.url || this.pl.url;
      this.keys.clear(); // les clés peuvent avoir changé avec le jeton
      if (this.state === "failed") {
        this.state = "paused"; // prêt à reprendre
        this.error = null;
      }
      this._emit("state");
    }

    async _emitChunk(chunk) {
      this.bytesOut += chunk.byteLength;
      try {
        await this.opts.write(chunk);
      } catch (e) {
        throw new HlsError("write", (e && e.message) || "écriture impossible", { fatal: true, cause: e });
      }
    }

    // MP4 classique : zone d'en-tête réservée au début, puis contenu des mdat. L'estimation de la réserve
    // attend le premier lot complet (mux.js émet un fragment par piste).
    async _feedClassic(frags) {
      const payloads = [];
      for (const f of frags) payloads.push(...this.builder.addFragment(f));
      if (!this.started) {
        this.started = true;
        await this._emitChunk(new Uint8Array(this.builder.reserveSize(this.pl.totalDuration, this.n)));
      }
      for (const p of payloads) await this._emitChunk(p);
    }

    async _process(data) {
      try {
        if (this.tx) {
          this.tx.push(data);
          this.tx.flush();
          const batch = this.pending.splice(0);
          if (this.classic) await this._feedClassic(batch);
          else for (const c of batch) await this._emitChunk(c);
        } else if (this.classic) {
          await this._feedClassic([data]);
        } else {
          await this._emitChunk(data);
        }
      } catch (e) {
        if (e instanceof HlsError) throw e;
        throw new HlsError("process", (e && e.message) || "erreur de traitement", { fatal: true, cause: e });
      }
    }

    _context(e, i, resource) {
      if (!(e instanceof HlsError)) return e;
      if (resource && !e.resource) e.resource = resource;
      if (e.resource === "playlist") return e;
      e.segmentIndex = i;
      e.total = this.n;
      e.position = this.starts[i] || 0;
      return e;
    }

    async run() {
      if (this.state === "done") return this.result;
      if (this.state === "running") throw new HlsError("busy", "Téléchargement déjà en cours.", { fatal: true });
      if (this._cancelled) {
        this.state = "cancelled";
        throw new HlsError("aborted", "Annulé", { fatal: true });
      }
      const o = this.opts;
      const ac = new AbortController();
      this._ac = ac;
      this._pausing = false;
      this.state = "running";
      this.error = null;
      this._emit("state");

      const net = {
        signal: ac.signal,
        fetchImpl: o.fetchImpl,
        limiter: o.limiter,
        retries: o.retries,
        timeoutMs: o.timeoutMs,
        retryBaseMs: o.retryBaseMs,
        onBytes: (n) => {
          this.netBytes += n;
          this._samples.push([Date.now(), this.netBytes]);
          this._emit("bytes");
        },
        onRetry: (info) => this._emit("retry", { retry: info, index: this._cur }),
      };
      const fetchSegment = makeSegmentFetcher(net, this.keys);

      try {
        const segs = this.pl.segments;
        if (this.pl.kind === "fmp4" && segs[0].map && !this.initWritten) {
          let init;
          try {
            init = await fetchBytes(segs[0].map.url, { ...net, range: segs[0].map.range });
          } catch (e) {
            throw this._context(e, 0, "init");
          }
          if (this.classic) this.builder.setInit(init);
          else await this._emitChunk(init);
          this.initWritten = true;
        }

        const inflight = new Map();
        const start = (i) => {
          if (i >= this.n || inflight.has(i)) return;
          const p = i === 0 && this.pl.first ? Promise.resolve(this.pl.first) : fetchSegment(segs[i]);
          p.catch(() => {}); // évite les "unhandled rejection" ; l'erreur est relancée au await
          inflight.set(i, p);
        };

        for (let i = this.next; i < this.n; i++) {
          this._cur = i;
          const conc = Math.max(1, o.concurrency || 6);
          for (let k = 0; k < conc; k++) start(i + k);
          let data;
          try {
            data = await inflight.get(i);
          } catch (e) {
            throw this._context(e, i);
          }
          inflight.delete(i);
          if (ac.signal.aborted) throw abortError();
          await this._process(data);
          if (i === 0) this.pl.first = null; // libère la mémoire
          this.next = i + 1;
          this.bytesIn += data.byteLength;
          this._emit("progress");
        }

        if (this.convert && !this.initDone) {
          throw new HlsError(
            "process",
            "Conversion MP4 impossible (codec non pris en charge par mux.js, ex. HEVC). Choisis le format TS brut.",
            { fatal: true }
          );
        }
        let faststart = null;
        if (this.classic) {
          if (!this.started || !this.builder.hasData()) {
            throw new HlsError("process", "Aucun échantillon exploitable dans ce flux (fMP4 non pris en charge).", { fatal: true });
          }
          const { head, tail, faststart: fs } = this.builder.finalize();
          faststart = fs;
          if (tail) await this._emitChunk(tail); // réserve insuffisante : moov à la fin (fichier valide)
          try {
            await o.patchHead(head);
          } catch (e) {
            throw new HlsError("write", (e && e.message) || "écriture impossible", { fatal: true, cause: e });
          }
        }
        this.result = { bytesOut: this.bytesOut, faststart };
        this.state = "done";
        this._emit("state");
        return this.result;
      } catch (e) {
        let err = e;
        if (this._cancelled || (isAbort(e) && !this._pausing)) {
          this.state = "cancelled";
          err = new HlsError("aborted", "Annulé", { fatal: true });
        } else if (this._pausing && isAbort(e)) {
          this.state = "paused";
          err = new HlsError("paused", "En pause");
        } else {
          if (!(err instanceof HlsError)) {
            err = new HlsError("process", (e && e.message) || String(e), { fatal: true, cause: e });
          }
          err.userMessage = describe(err);
          err.resumable = !err.fatal;
          this.state = "failed";
        }
        this.error = err;
        this._emit("state");
        throw err;
      } finally {
        ac.abort(); // coupe tout ce qui serait encore en vol
      }
    }
  }

  // Compatibilité : téléchargement en une fois (sans reprise)
  async function download(pl, opts = {}) {
    const job = new DownloadJob(pl, opts);
    const t0 = Date.now();
    if (opts.onProgress) {
      job.on((ev) => {
        if (ev.type !== "progress") return;
        const st = job.stats();
        opts.onProgress({ done: st.done, total: st.total, bytes: st.bytes, elapsed: (Date.now() - t0) / 1000 });
      });
    }
    return job.run();
  }

  const API = {
    patchInitDuration, parseMaster, parseMedia, isMaster, prepare, download, sniff, extFor, fetchText, fetchBytes,
    DownloadJob, RateLimiter, HlsError, describe, fmtPos, probe: probeFirstSegment,
  };
  if (typeof module !== "undefined" && module.exports) module.exports = API;
  else root.HLS = API;
})(typeof globalThis !== "undefined" ? globalThis : self);
