// Gestionnaire de téléchargements HLS : file d'attente, reprise, limite de débit, erreurs détaillées.

// Firefox expose `browser` (promesses), Chrome expose `chrome` (promesses aussi en MV3)
const api = typeof browser !== "undefined" ? browser : chrome;

const $ = (id) => document.getElementById(id);
function el(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids) if (c != null) e.append(c);
  return e;
}
const show = (node, on) => { node.hidden = !on; };

const fmtSize = (n) => (n > 1e9 ? (n / 1e9).toFixed(2) + " Go" : n > 1e6 ? (n / 1e6).toFixed(1) + " Mo" : Math.round(n / 1e3) + " Ko");
const fmtTime = (s) => HLS.fmtPos(s);
const safeName = (s) => s.replace(/[\\/:*?"<>|]+/g, "_").replace(/\s+/g, " ").trim().slice(0, 100) || "video";
const hostOf = (u) => { try { return new URL(u).hostname; } catch { return ""; } };

// ---------------------------------------------------------------- réglages

const RATES = [[0, "Illimitée"], [256e3, "256 Ko/s"], [512e3, "512 Ko/s"], [1e6, "1 Mo/s"], [2e6, "2 Mo/s"], [5e6, "5 Mo/s"], [10e6, "10 Mo/s"]];
const settings = { maxParallel: 2, segConc: 6, rate: 0 };
const limiter = new HLS.RateLimiter(0); // partagé par tous les téléchargements
const queue = new JobQueue({ maxParallel: 2, onChange: onQueueChange });

function fillSelect(sel, options, value) {
  sel.replaceChildren(...options.map(([v, l]) => new Option(l, String(v))));
  sel.value = String(value);
}
function applySettings() {
  limiter.setRate(settings.rate);
  queue.setMaxParallel(settings.maxParallel);
  for (const e of queue.entries) e.job.opts.concurrency = settings.segConc;
}
async function loadSettings() {
  try {
    const r = await api.storage.local.get("mgSettings");
    Object.assign(settings, r.mgSettings || {});
  } catch {}
  fillSelect($("maxParallel"), [1, 2, 3, 4].map((n) => [n, String(n)]), settings.maxParallel);
  fillSelect($("segConc"), [1, 2, 4, 6, 8].map((n) => [n, String(n)]), settings.segConc);
  fillSelect($("rate"), RATES, settings.rate);
  applySettings();
}
function onSettingChange() {
  settings.maxParallel = +$("maxParallel").value;
  settings.segConc = +$("segConc").value;
  settings.rate = +$("rate").value;
  applySettings();
  api.storage.local.set({ mgSettings: settings }).catch(() => {});
}

// ---------------------------------------------------------------- Referer / Origin

// Certains serveurs exigent le bon Referer/Origin : on les impose aux requêtes de CET onglet vers les
// hôtes de la vidéo. Une règle par vidéo (hôtes de la playlist, des segments, des clés).
let tabIdPromise = null;
const myTabId = () => (tabIdPromise ||= api.tabs.getCurrent().then((t) => (t ? t.id : null)).catch(() => null));
const ruleRecs = new Set(); // enregistrements portant une règle (pour le ménage à la fermeture)

function hostsOf(pl) {
  const s = new Set();
  const add = (u) => { const h = hostOf(u); if (h) s.add(h); };
  add(pl.url);
  for (const sg of pl.segments) {
    add(sg.url);
    if (sg.key && sg.key.uri) add(sg.key.uri);
    if (sg.map) add(sg.map.url);
  }
  return s;
}
async function applyHeaderRule(rec) {
  if (!rec.pageUrl || !rec.hosts.size) return;
  const tabId = await myTabId();
  if (tabId == null) return;
  if (rec.ruleId == null) rec.ruleId = Math.floor(Math.random() * 2e9) + 1;
  const mk = (withOrigin) => ({
    id: rec.ruleId,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "referer", operation: "set", value: rec.pageUrl },
        ...(withOrigin ? [{ header: "origin", operation: "set", value: new URL(rec.pageUrl).origin }] : []),
      ],
    },
    condition: { tabIds: [tabId], requestDomains: [...rec.hosts], resourceTypes: ["xmlhttprequest", "other"] },
  });
  const apply = (rule) => api.declarativeNetRequest.updateSessionRules({ removeRuleIds: [rec.ruleId], addRules: [rule] });
  try {
    await apply(mk(true));
  } catch {
    try { await apply(mk(false)); } catch (e) { console.warn("Règle d'en-têtes refusée", e); rec.ruleId = null; }
  }
}
async function dropHeaderRule(rec) {
  if (rec.ruleId == null) return;
  const id = rec.ruleId;
  rec.ruleId = null;
  try { await api.declarativeNetRequest.updateSessionRules({ removeRuleIds: [id] }); } catch {}
}
window.addEventListener("pagehide", () => {
  for (const rec of ruleRecs) if (rec.ruleId != null) api.declarativeNetRequest.updateSessionRules({ removeRuleIds: [rec.ruleId] });
});

// ---------------------------------------------------------------- permission d'accès aux sites

// Firefox traite les permissions d'hôtes du MV3 comme optionnelles : sans elles, les requêtes vers les
// serveurs de la vidéo sont bloquées par CORS. On propose de les accorder (geste utilisateur requis).
let permissionReady = Promise.resolve();
async function initPermission() {
  try {
    if (await api.permissions.contains({ origins: ["<all_urls>"] })) return;
  } catch {
    return;
  }
  $("permBanner").hidden = false;
  permissionReady = new Promise((resolve) => {
    $("grant").addEventListener("click", async () => {
      try {
        if (await api.permissions.request({ origins: ["<all_urls>"] })) {
          $("permBanner").hidden = true;
          resolve();
        }
      } catch (e) {
        console.error(e);
      }
    });
  });
}

// ---------------------------------------------------------------- écriture du fichier

const MIMES = { mp4: "video/mp4", ts: "video/mp2t", aac: "audio/aac", mp3: "audio/mpeg" };
const cleanName = (n) => n.replace(/[\\/:*?"<>|]+/g, "_").trim() || "video";

// Remet un fichier (File / Blob) au gestionnaire de téléchargements du navigateur et attend la fin.
function saveBlobUrl(url, name) {
  return new Promise((resolve, reject) => {
    const states = new Map();
    let id = null;
    const done = (state, error) => {
      api.downloads.onChanged.removeListener(onChanged);
      if (state === "complete") resolve();
      else reject(new Error("Le navigateur a interrompu l'enregistrement" + (error ? ` (${error})` : "") + "."));
    };
    const onChanged = (d) => {
      if (!d.state) return;
      states.set(d.id, d.state.current);
      if (id !== null && d.id === id && ["complete", "interrupted"].includes(d.state.current)) done(d.state.current, d.error && d.error.current);
    };
    api.downloads.onChanged.addListener(onChanged);
    api.downloads
      .download({ url, filename: cleanName(name), conflictAction: "uniquify" })
      .then((newId) => {
        id = newId;
        const st = states.get(id); // l'événement a pu arriver avant la réponse
        if (st === "complete" || st === "interrupted") done(st);
      })
      .catch((e) => {
        api.downloads.onChanged.removeListener(onChanged);
        reject(e);
      });
  });
}

// Un « écrivain » reçoit les octets d'une vidéo :
//   write(chunk) / patchHead(head)   écriture séquentielle puis réécriture de l'en-tête à la position 0
//   finish()                         ferme le flux (idempotent)
//   export()                         (Firefox / mémoire) copie vers « Téléchargements » ; peut être retentée
//   discard()                        abandonne et supprime tout fichier temporaire
function fsaWriter(handle) {
  let w = null;
  let finished = false;
  return {
    async init() { w = await handle.createWritable(); return this; },
    write: (c) => w.write(c),
    patchHead: (head) => w.write({ type: "write", position: 0, data: head }),
    finish: async () => { if (!finished) { finished = true; await w.close(); } },
    discard: async () => { if (!finished) { finished = true; await w.abort().catch(() => {}); } },
  };
}

// Firefox : pas de showSaveFilePicker. On écrit dans le système de fichiers privé de l'extension (OPFS,
// sur disque, accès positionnel pour l'en-tête MP4), puis on copie vers « Téléchargements ».
async function opfsWriter(name, ext) {
  const dir = await navigator.storage.getDirectory();
  try { // ménage des restes d'une session interrompue (> 24 h)
    for await (const [n, h] of dir.entries()) {
      if (n.startsWith("mg-") && h.kind === "file" && (await h.getFile()).lastModified < Date.now() - 864e5) {
        await dir.removeEntry(n).catch(() => {});
      }
    }
  } catch {}
  const tmp = `mg-${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const fh = await dir.getFileHandle(tmp, { create: true });
  if (typeof fh.createWritable !== "function") {
    await dir.removeEntry(tmp).catch(() => {});
    throw new Error("createWritable indisponible");
  }
  const w = await fh.createWritable();
  let finished = false;
  const cleanup = () => dir.removeEntry(tmp).catch(() => {});
  return {
    needsExport: true,
    write: (c) => w.write(c),
    patchHead: (head) => w.write({ type: "write", position: 0, data: head }),
    finish: async () => { if (!finished) { finished = true; await w.close(); } },
    export: async () => {
      const url = URL.createObjectURL(await fh.getFile());
      try { await saveBlobUrl(url, name); } finally { URL.revokeObjectURL(url); }
      await cleanup();
    },
    discard: async () => { if (!finished) { finished = true; await w.abort().catch(() => {}); } await cleanup(); },
  };
}

// Dernier recours (navigation privée Firefox, etc.) : tout en mémoire, limité par la RAM.
function memoryWriter(name, mime) {
  let chunks = [];
  return {
    needsExport: true,
    write: async (c) => { chunks.push(c); },
    // Le MP4 classique écrit d'abord une zone d'en-tête réservée (1er morceau) : on la remplace à la fin
    patchHead: async (head) => { chunks[0] = head; },
    finish: async () => {},
    export: async () => {
      const url = URL.createObjectURL(new Blob(chunks, { type: mime }));
      try { await saveBlobUrl(url, name); } finally { URL.revokeObjectURL(url); }
      chunks = [];
    },
    discard: async () => { chunks = []; },
  };
}

// Doit être appelé tout de suite dans un gestionnaire de clic (le sélecteur de fichier exige un geste récent).
async function openWriter(name, ext) {
  const mime = MIMES[ext] || "application/octet-stream";
  if (window.showSaveFilePicker) { // Chrome / Edge : sélecteur de fichier, écriture directe sur le disque
    const handle = await showSaveFilePicker({
      suggestedName: name,
      types: [{ description: ext.toUpperCase(), accept: { [mime]: ["." + ext] } }],
    });
    return fsaWriter(handle).init();
  }
  if (navigator.storage && navigator.storage.getDirectory) { // Firefox : OPFS puis téléchargement
    try {
      return await opfsWriter(name, ext);
    } catch (e) {
      console.warn("OPFS indisponible, repli en mémoire :", e);
    }
  }
  return memoryWriter(name, mime);
}

// ---------------------------------------------------------------- ajout d'une vidéo (carte « nouvelle vidéo »)

let pendingSeq = 0;
const KIND_LABEL = { ts: "MPEG-TS", fmp4: "MP4 fragmenté", aac: "AAC (audio)", mp3: "MP3 (audio)", unknown: "inconnu" };

function addPending({ u, p, t }) {
  if (!u) return null;
  const rec = {
    id: ++pendingSeq, srcUrl: u, pageUrl: p || "", title: t || "video",
    hosts: new Set(), ruleId: null, state: "analyzing", error: "", variants: null, variantIdx: 0, pl: null, token: 0,
  };
  ruleRecs.add(rec);
  const ui = (rec.ui = {
    url: el("div", { class: "meta", text: u }),
    qLabel: el("span", { text: "Qualité", hidden: true }),
    variant: el("select", { "data-role": "variant", hidden: true, onchange: () => onVariantChange(rec) }),
    format: el("select", { "data-role": "format", disabled: true, onchange: () => updateName(rec) }),
    name: el("input", { type: "text", "data-role": "name" }),
    info: el("div", { class: "msg", "data-role": "info" }),
    add: el("button", { class: "primary", "data-role": "add", text: "Ajouter à la file", disabled: true, onclick: () => confirmAdd(rec) }),
    remove: el("button", { "data-role": "remove-pending", text: "Retirer", onclick: () => removePending(rec) }),
  });
  ui.name.value = safeName(rec.title);
  rec.card = el("div", { class: "card", "data-role": "pending" },
    el("div", { class: "title", text: "Nouvelle vidéo" }), ui.url,
    el("div", { class: "fields" }, ui.qLabel, ui.variant, el("span", { text: "Format" }), ui.format, el("span", { text: "Nom" }), ui.name),
    ui.info, el("div", { class: "actions" }, ui.add, ui.remove));
  $("pending").append(rec.card);
  renderPending(rec);
  analyze(rec);
  return rec;
}

function removePending(rec) {
  rec.token++; // ignore les résultats d'analyse encore en cours
  dropHeaderRule(rec);
  ruleRecs.delete(rec);
  rec.card.remove();
  scheduleRender();
}

async function analyze(rec) {
  const token = ++rec.token;
  await permissionReady;
  rec.state = "analyzing"; rec.error = "";
  renderPending(rec);
  try {
    rec.hosts.add(hostOf(rec.srcUrl));
    await applyHeaderRule(rec);
    let text;
    try { text = await HLS.fetchText(rec.srcUrl); }
    catch (e) { if (e instanceof HLS.HlsError) { e.resource = "playlist"; e.userMessage = HLS.describe(e); } throw e; }
    if (token !== rec.token) return;
    if (HLS.isMaster(text)) {
      const { variants } = HLS.parseMaster(text, rec.srcUrl);
      if (!variants.length) throw new Error("Playlist maître sans variante.");
      rec.variants = variants; rec.variantIdx = 0;
      ui_fillVariants(rec);
      await analyzeMedia(rec, variants[0].url, null, token);
    } else {
      await analyzeMedia(rec, rec.srcUrl, text, token);
    }
  } catch (e) {
    if (token !== rec.token) return;
    rec.state = "error"; rec.error = e.userMessage || e.message;
  }
  renderPending(rec);
}

async function analyzeMedia(rec, url, text, token) {
  rec.hosts.add(hostOf(url));
  await applyHeaderRule(rec);
  const pl = await HLS.prepare(url, { text, probe: false });
  for (const h of hostsOf(pl)) rec.hosts.add(h);
  await applyHeaderRule(rec); // maintenant on connaît tous les hôtes (segments, clés) : Referer avant le 1er segment
  await HLS.probe(pl);
  if (token !== rec.token) return;
  rec.pl = pl;
  rec.state = "ready";
  ui_fillFormats(rec);
}

function ui_fillVariants(rec) {
  const sel = rec.ui.variant;
  sel.replaceChildren(...rec.variants.map((v, i) => new Option([v.resolution || "audio", Math.round(v.bandwidth / 1000) + " kb/s"].join(" · "), String(i))));
  sel.value = String(rec.variantIdx);
  rec.ui.qLabel.hidden = false;
  sel.hidden = false;
}
async function onVariantChange(rec) {
  rec.variantIdx = +rec.ui.variant.value;
  const token = ++rec.token;
  rec.state = "analyzing"; rec.pl = null;
  renderPending(rec);
  try { await analyzeMedia(rec, rec.variants[rec.variantIdx].url, null, token); }
  catch (e) { if (token !== rec.token) return; rec.state = "error"; rec.error = e.userMessage || e.message; }
  renderPending(rec);
}

function ui_fillFormats(rec) {
  const fmt = rec.ui.format;
  const kind = rec.pl.kind;
  fmt.replaceChildren();
  const add = (v, label) => fmt.append(new Option(label, v));
  if (kind === "ts") {
    add("mp4", "MP4 classique (recommandé)");
    add("fmp4", "MP4 fragmenté (ancien format, sans index)");
    add("raw", "TS brut (aucune conversion)");
  } else if (kind === "fmp4") {
    add("mp4", "MP4 classique (recommandé)");
    add("fmp4", "MP4 fragmenté (copie brute des segments)");
  } else add("raw", { aac: "AAC", mp3: "MP3", unknown: "Brut (.bin)" }[kind]);
  fmt.disabled = fmt.options.length < 2;
  updateName(rec);
}
function updateName(rec) {
  if (!rec.pl) return;
  const base = rec.ui.name.value.replace(/\.[A-Za-z0-9]{2,4}$/, "") || safeName(rec.title);
  rec.ui.name.value = base + "." + HLS.extFor(rec.pl.kind, rec.ui.format.value);
}

function renderPending(rec) {
  const { ui } = rec;
  ui.add.disabled = rec.state !== "ready";
  ui.variant.disabled = rec.state === "analyzing";
  if (rec.state === "analyzing") { ui.info.className = "msg"; ui.info.textContent = "Analyse du flux…"; return; }
  if (rec.state === "error") { ui.info.className = "msg error"; ui.info.textContent = rec.error; return; }
  const pl = rec.pl;
  const warn = [];
  if (rec.variants && rec.variants[rec.variantIdx].separateAudio) warn.push("Cette qualité a une piste audio séparée : elle n'est pas incluse (la vidéo sera muette).");
  if (pl.kind === "unknown") warn.push("Format des segments non reconnu : ils seront simplement mis bout à bout.");
  ui.info.className = "msg";
  ui.info.textContent = `${pl.segments.length} segments · ~${fmtTime(pl.totalDuration)} · conteneur ${KIND_LABEL[pl.kind]} · ` +
    (pl.encrypted ? "chiffré AES-128 (déchiffré localement)" : "non chiffré");
  for (const w of warn) ui.info.append(el("div", { class: "msg warn", text: "⚠ " + w }));
}

// Clic sur « Ajouter à la file » : choix de l'emplacement (Chrome) puis mise en file.
async function confirmAdd(rec) {
  if (rec.state !== "ready") return;
  const format = rec.ui.format.value;                    // lu AVANT tout await : le sélecteur de fichier
  const name = rec.ui.name.value.trim() || "video";      // exige un geste utilisateur tout récent
  const ext = HLS.extFor(rec.pl.kind, format);
  let writer;
  try {
    writer = await openWriter(name, ext);
  } catch (e) {
    if (e.name !== "AbortError") { rec.ui.info.className = "msg error"; rec.ui.info.textContent = "Impossible d'ouvrir le fichier : " + e.message; }
    return;
  }
  enqueue(rec, writer, format, name);
  rec.card.remove();
  rec.pl = null; // la mémoire est désormais portée par le job
}

// ---------------------------------------------------------------- file d'attente (cartes de téléchargement)

const LABEL = { queued: "En attente", running: "En cours", paused: "En pause", failed: "Interrompu", done: "Terminé", cancelled: "Annulé" };
const URL_FIX_CODES = ["http-auth", "http-gone", "key"];
const isFatal = (e) => e.status === "failed" && e.error && e.error.resumable === false;

function enqueue(rec, writer, format, name) {
  const job = new HLS.DownloadJob(rec.pl, {
    format, concurrency: settings.segConc, limiter,
    write: (c) => writer.write(c),
    patchHead: (h) => writer.patchHead(h),
  });
  const entry = {
    name, rec, job, writer, notice: "", phase: null, finished: false, exported: false, cleaned: false, discarded: false,
    run: async () => {
      entry.notice = ""; entry.phase = null;
      await job.run(); // lève une erreur (pause, annulation, panne) et garde l'état pour la reprise
      try {
        if (!entry.finished) { await writer.finish(); entry.finished = true; }
        if (writer.export && !entry.exported) {
          entry.phase = "export";
          scheduleRender();
          await writer.export();
          entry.exported = true;
        }
      } catch (e) {
        const err = e instanceof Error ? e : new Error(String(e));
        err.code = "export"; err.resumable = true;
        err.userMessage = `L'enregistrement final a échoué : ${err.message} Clique sur « Reprendre » pour réessayer.`;
        throw err;
      }
      entry.phase = null;
      return job.result;
    },
    pause: () => job.pause(),
    cancel: () => job.cancel(),
  };
  job.on((ev) => {
    if (ev.type === "retry") {
      const r = ev.retry;
      const why = { "http-server": `HTTP ${r.error.status}`, "http-ratelimit": "HTTP 429", network: "erreur réseau", timeout: "délai dépassé" }[r.error.code] || r.error.message;
      entry.notice = `Nouvelle tentative ${r.attempt}/${r.max} dans ${(r.delay / 1000).toFixed(r.delay < 10000 ? 1 : 0)} s (${why}) — segment ${(ev.index || 0) + 1}`;
    } else if (ev.type === "progress") entry.notice = "";
    scheduleRender();
  });
  buildJobCard(entry);
  queue.add(entry);
}

function buildJobCard(entry) {
  const ui = (entry.ui = {
    title: el("div", { class: "title", text: entry.name }),
    badge: el("span", { class: "badge", "data-role": "badge" }),
    meta: el("div", { class: "meta" }),
    bar: el("progress", { value: 0, max: 1, "data-role": "bar" }),
    stats: el("div", { class: "stats", "data-role": "stats" }),
    msg: el("div", { class: "msg", "data-role": "msg" }),
    pause: el("button", { "data-role": "pause", text: "Pause", onclick: () => queue.pause(entry.id) }),
    resume: el("button", { class: "primary", "data-role": "resume", text: "Reprendre", onclick: () => queue.resume(entry.id) }),
    cancel: el("button", { "data-role": "cancel", text: "Annuler", onclick: () => queue.cancel(entry.id) }),
    remove: el("button", { "data-role": "remove", text: "Retirer", onclick: () => queue.remove(entry.id) }),
    urlInput: el("input", { type: "text", "data-role": "newurl", placeholder: "Nouvelle URL de la playlist (.m3u8)" }),
    urlGo: el("button", { class: "primary", "data-role": "resume-url", text: "Reprendre avec cette URL", onclick: () => resumeWithUrl(entry) }),
  });
  ui.form = el("div", { class: "urlform", hidden: true }, ui.urlInput, ui.urlGo);
  const pl = entry.job.pl;
  ui.meta.textContent = `${hostOf(entry.rec.srcUrl)} · ${pl.segments.length} segments · ~${fmtTime(pl.totalDuration)}` + (pl.encrypted ? " · AES-128" : "");
  entry.card = el("div", { class: "card", "data-role": "job", "data-id": "" },
    el("div", { class: "row" }, el("div", { class: "grow" }, ui.title, ui.meta), ui.badge),
    ui.bar, ui.stats, ui.msg, ui.form,
    el("div", { class: "actions" }, ui.pause, ui.resume, ui.cancel, ui.remove));
}

function updateEntry(entry) {
  const ui = entry.ui;
  const st = entry.status;
  const fatal = isFatal(entry);
  const s = entry.job.stats();
  entry.card.setAttribute("data-id", entry.id);
  entry.card.setAttribute("data-status", st);
  ui.badge.textContent = fatal ? "Échec" : st === "running" && entry.phase === "export" ? "Enregistrement" : LABEL[st];
  ui.badge.className = "badge " + (fatal ? "failed" : st);
  ui.bar.value = s.total ? s.done / s.total : 0;

  let stats = `${s.done}/${s.total} segments · ${fmtSize(s.bytes)}`;
  if (st === "running" && entry.phase !== "export") stats += ` · ${fmtSize(s.speed)}/s` + (s.eta > 0 && s.done < s.total ? ` · reste ~${fmtTime(s.eta)}` : "");
  ui.stats.textContent = stats;

  let text = "", cls = "msg";
  if (st === "queued") { text = `En attente (${queue.entries.filter((e) => e.status === "queued").indexOf(entry) + 1}ᵉ dans la file)`; }
  else if (st === "running") { text = entry.phase === "export" ? "Copie vers le dossier Téléchargements…" : entry.notice; cls = entry.notice ? "msg warn" : "msg"; }
  else if (st === "paused") { text = `En pause — la reprise repartira au segment ${s.done + 1}.`; }
  else if (st === "failed") { text = (entry.error && (entry.error.userMessage || entry.error.message)) || "Erreur."; cls = "msg error"; }
  else if (st === "cancelled") { text = "Annulé."; }
  else if (st === "done") {
    const r = entry.job.result || {};
    text = `Terminé ✓ — ${fmtSize(r.bytesOut || 0)}` + (entry.writer.needsExport ? " — enregistré dans le dossier Téléchargements" : "") + (r.faststart === false ? " — index placé à la fin du fichier" : "");
    cls = "msg ok";
  }
  ui.msg.className = cls; ui.msg.textContent = text;

  show(ui.pause, (st === "running" && entry.phase !== "export") || st === "queued");
  show(ui.resume, st === "paused" || (st === "failed" && !fatal));
  show(ui.cancel, !["done", "cancelled"].includes(st) && !fatal && !(st === "running" && entry.phase === "export"));
  show(ui.remove, st === "done" || st === "cancelled" || fatal);
  show(ui.form, st === "failed" && !fatal && !!entry.error && URL_FIX_CODES.includes(entry.error.code));
  ui.urlGo.disabled = !!entry.urlBusy;
}

// Jeton expiré : on charge une playlist fraîche de la MÊME vidéo, le job reprend au segment qui a échoué.
function pickVariant(vs, want) {
  if (!want) return vs[0];
  let best = vs[0], score = Infinity;
  for (const v of vs) {
    const sc = (v.resolution === want.resolution ? 0 : 1e12) + Math.abs(v.bandwidth - want.bandwidth);
    if (sc < score) { best = v; score = sc; }
  }
  return best;
}
async function resumeWithUrl(entry) {
  const url = entry.ui.urlInput.value.trim();
  if (!url) return;
  entry.urlBusy = true;
  entry.ui.msg.className = "msg"; entry.ui.msg.textContent = "Vérification de la nouvelle playlist…";
  updateEntry(entry);
  try {
    const rec = entry.rec;
    rec.hosts.add(hostOf(url));
    await applyHeaderRule(rec);
    let text;
    try { text = await HLS.fetchText(url); }
    catch (e) { if (e instanceof HLS.HlsError) { e.resource = "playlist"; e.userMessage = HLS.describe(e); } throw e; }
    let mediaUrl = url, mediaText = text;
    if (HLS.isMaster(text)) {
      const { variants } = HLS.parseMaster(text, url);
      if (!variants.length) throw new Error("Playlist maître sans variante.");
      mediaUrl = pickVariant(variants, rec.variants && rec.variants[rec.variantIdx]).url;
      mediaText = null;
    }
    const newPl = await HLS.prepare(mediaUrl, { text: mediaText, probe: false });
    for (const h of hostsOf(newPl)) rec.hosts.add(h);
    await applyHeaderRule(rec);
    entry.job.replacePlaylist(newPl); // vérifie : même nombre de segments, même durée
    rec.srcUrl = url;
    entry.urlBusy = false;
    entry.ui.urlInput.value = "";
    queue.resume(entry.id);
  } catch (e) {
    entry.urlBusy = false;
    updateEntry(entry);
    entry.ui.msg.className = "msg error";
    entry.ui.msg.textContent = "Cette URL ne convient pas : " + (e.userMessage || e.message);
  }
}

// Ménage quand une entrée atteint un état final (la règle Referer n'est gardée que tant qu'une reprise est possible).
function onQueueChange() {
  for (const e of queue.entries) {
    if (e.cleaned) continue;
    if (e.status === "done") {
      e.cleaned = true;
      dropHeaderRule(e.rec);
    } else if (e.status === "cancelled" || isFatal(e)) {
      e.cleaned = true;
      dropHeaderRule(e.rec);
      if (!e.discarded) { e.discarded = true; Promise.resolve(e.writer.discard()).catch(() => {}); }
    }
  }
  scheduleRender();
}

let renderTimer = 0;
function scheduleRender() {
  if (renderTimer) return;
  renderTimer = setTimeout(() => { renderTimer = 0; renderAll(); }, 60);
}
function renderAll() {
  const jobs = $("jobs");
  const present = new Set(queue.entries.map((e) => e.card));
  for (const c of [...jobs.children]) if (!present.has(c)) c.remove();
  for (const e of queue.entries) {
    if (e.card.parentNode !== jobs) jobs.append(e.card);
    updateEntry(e);
  }
  show($("queueTitle"), queue.entries.length > 0);
  show($("empty"), queue.entries.length === 0 && $("pending").children.length === 0);
}

// ---------------------------------------------------------------- démarrage

window.addEventListener("beforeunload", (e) => {
  if (queue.hasActive()) { e.preventDefault(); e.returnValue = ""; }
});
// Retour du réseau : les téléchargements tombés en panne à cause de la connexion reprennent seuls
window.addEventListener("online", () => queue.resumeNetworkFailures());

// Le popup envoie les vidéos suivantes à ce gestionnaire déjà ouvert
api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "mg-add" && msg.u) {
    addPending({ u: msg.u, p: msg.p, t: msg.t });
    scheduleRender();
    sendResponse({ ok: true });
  }
});

async function init() {
  // Écouteurs d'abord : un réglage modifié pendant le chargement ne doit pas être perdu
  $("maxParallel").addEventListener("change", onSettingChange);
  $("segConc").addEventListener("change", onSettingChange);
  $("rate").addEventListener("change", onSettingChange);
  await loadSettings();
  await initPermission();
  $("addUrl").addEventListener("click", () => {
    const u = $("newUrl").value.trim();
    if (!u) return;
    addPending({ u, p: "", t: "" });
    $("newUrl").value = "";
    scheduleRender();
  });
  const q = new URLSearchParams(location.search);
  if (q.get("u")) addPending({ u: q.get("u"), p: q.get("p") || "", t: q.get("t") || "video" });
  renderAll();
}
// Accès pour le débogage et les tests automatisés
window.mgDebug = { queue, limiter, settings };
init();
